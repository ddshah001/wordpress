<?php get_header(); ?>

<div id="main" class="group fourohfour">
		
		<h2>404: Page not Found!?</h2>
		
		<img class="aligncenter" src="<?php print IMAGES;?>/404.jpg" alt="404'd!"/>
		
		<p>I am just as surprised as you are! Maybe we should just move along back to the <a href="<?php bloginfo('home'); ?>">home page</a>.</p>
		
</div>

<?php get_footer(); ?>