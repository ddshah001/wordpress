			</div>	<!-- End Main Area -->

		</div>
		<!--end container-->
	</div>

	<!--Footer Information-->
	<footer class="group">

		<p>&copy; <?php bloginfo('name');?>, <?=date('Y'); ?>. All Rights Reserved</p>
	</footer>
	<!-- End Footer Information -->
<?php wp_footer(); ?>

</body>
</html>
