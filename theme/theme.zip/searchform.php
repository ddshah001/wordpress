<div class="searchbar">
	<form name="search" method="get" action"/">
			<input type="text" name="s" value="Search…" />
			<input type="submit" name="submit" value="Search!" />
	</form>
</div>