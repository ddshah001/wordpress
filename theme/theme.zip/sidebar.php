<aside class="right-col">
						<div class="widget">
							<h3>ABOUT US</h3>
							<p>Ac, vestibulum at eros. Praesent commodo cursus magna, vel scelerisque nisl consectetur et. Maecenas faucibus mollis interdum. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>

							<p>Vestibulum id ligula porta felis euismod semper. Curabitur blandit tempus porttitor. Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</p>

							<p><a href="#">MORE ABOUT US...</a></p>
						</div>
					</aside>
